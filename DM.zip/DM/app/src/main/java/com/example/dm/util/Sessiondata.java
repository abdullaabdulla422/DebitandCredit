package com.example.dm.util;

public class Sessiondata {
    private static Sessiondata instance = null;
    private int previousTabSelection=0;
    public static Sessiondata getInstance() {
        if (instance == null){
            instance = new Sessiondata();
        }
        return instance;
    }

    public int getPreviousTabSelection() {
        return previousTabSelection;
    }

    public void setPreviousTabSelection(int previousTabSelection) {
        this.previousTabSelection = previousTabSelection;
    }
}
