package com.example.dm;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class LoginActivity extends AppCompatActivity {
EditText username,password;
Button btnLogin;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        username=findViewById(R.id.edt_username);
        password=findViewById(R.id.edt_pwd);
        btnLogin=findViewById(R.id.btn_login);
        
        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String user=  username.getText().toString();
                String pwd= password.getText().toString();

                if((user.equals("dmi"))&(pwd.equals("dmi786"))){
                    Toast.makeText(LoginActivity.this, "successfully login", Toast.LENGTH_SHORT).show();
                    Intent i=new Intent(LoginActivity.this,Data.class);
                    startActivity(i);
                }else if(username.getText().toString().length()==0||password.getText().toString().length()==0){
                    Toast.makeText(LoginActivity.this, "please enter the empty fills", Toast.LENGTH_SHORT).show();
                }else {
                    Toast.makeText(LoginActivity.this, "incorrect login", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}
